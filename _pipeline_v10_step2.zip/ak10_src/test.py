import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1200,'height':900})
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append('C:'+m.text) if m.type=='error' else None)
        await pg.route('**/*',lambda r: r.abort() if 'localhost' not in r.request.url else r.continue_())
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_selector('.acard',timeout=15000)
        print('home cards',await pg.locator('.acard').count(),'| stat:',await pg.inner_text('#stat'))
        await pg.wait_for_function("document.getElementById('ldst').hidden===true",timeout=60000)
        print('prefetch done; ldst hidden')
        await pg.fill('#q','insulin DKA'); await pg.wait_for_timeout(600)
        print('search:',await pg.inner_text('#stat')); print(' first:',(await pg.locator('.doc .t b').first.inner_text()))
        n=await pg.locator('.doc').count(); print(' docs',n,'title-only',await pg.locator('.hit.tonly').count())
        await pg.fill('#q','ERC advanced life support'); await pg.wait_for_timeout(600)
        print('gl search:',await pg.inner_text('#stat'),'|',await pg.locator('.doc').first.inner_text())
        await pg.fill('#q',''); await pg.wait_for_timeout(300)
        await pg.click('.acard[data-area="TRA"]'); await pg.wait_for_timeout(300)
        print('area TRA docs',await pg.locator('.doc').count(), 'läs-här buttons',await pg.locator('[data-act=open]').count())
        await pg.locator('[data-act=open]').first.click(); await pg.wait_for_selector('#reader:not([hidden])',timeout=5000)
        print('reader:',await pg.inner_text('#rtitle'),'| pages',await pg.locator('#pnav button').count())
        await pg.screenshot(path='shot_reader.png'); await pg.click('#rclose')
        await pg.click('#home'); await pg.wait_for_timeout(300)
        await pg.click('.acard.gl >> nth=0'); await pg.wait_for_timeout(300)
        print('gl area cards',await pg.locator('.doc.gl').count(),'| läs-här in gl area',await pg.locator('.doc.gl [data-act=open]').count(),'| links',await pg.locator('.doc.gl a').count())
        await pg.screenshot(path='shot_gl.png',full_page=True)
        # network: which shards were requested
        print('errors',errs[:5])
        # mobile
        pm=await b.new_page(viewport={'width':390,'height':844}); await pm.route('**/*',lambda r: r.abort() if 'localhost' not in r.request.url else r.continue_())
        await pm.goto('http://localhost:8765/index.html'); await pm.wait_for_selector('.acard'); await pm.screenshot(path='shot_mobile.png')
        await b.close()
asyncio.run(main())
