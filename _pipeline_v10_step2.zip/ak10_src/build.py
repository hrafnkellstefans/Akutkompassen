"""Akutkompassen v10 – step 2 build: sharded data + link-only tier for guidelines.
Input : v9_shell.html (v9 index.html with the data blob removed), v9_data.json
Output: dist/index.html, dist/data/index.json, dist/data/<AREA>.json, dist/sw.js, manifest, icons, README
"""
import json, os, re, shutil, datetime
S = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(f'{S}/v9_data.json'))
shell = open(f'{S}/v9_shell.html', encoding='utf8').read()
VERSION = 'ak-v10s2'   # bump on every release
UPDATED = 'sept 2026'
dist = f'{S}/dist'; shutil.rmtree(dist, ignore_errors=True); os.makedirs(f'{dist}/data')

# ---------- data ----------
meta = []; shards = {}
for d in D['docs']:
    gl = d.get('kind') == 'gl'
    m = {k: d[k] for k in ('id', 't', 'a', 'tier', 'yr', 'note', 'np', 'url') if k in d}
    m['kind'] = 'gl' if gl else 'pm'
    if gl: m['soc'] = d.get('soc', '')
    m['lvl'] = 'int' if gl else 'lokal'          # lokal | nat | int
    m['txt'] = 0 if gl else 1                     # 1 = full text available in shard (tier A)
    meta.append(m)
    if not gl:
        shards.setdefault(d['a'], {})[d['id']] = d['c']
index = {'v': VERSION, 'updated': UPDATED, 'areas': D['areas'], 'docs': meta,
         'shards': {a: f'data/{a}.json' for a in shards}}
json.dump(index, open(f'{dist}/data/index.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
for a, docs in shards.items():
    json.dump({'v': VERSION, 'area': a, 'docs': docs}, open(f'{dist}/data/{a}.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))

# ---------- app js ----------
i = shell.find('<script>', shell.find('id="data"')); head = shell[:i]; js = shell[i:]
def rep(old, new, count=1):
    global js
    assert js.count(old) >= 1, old[:80]
    js = js.replace(old, new, count)

# 1. loader
rep("""const DATA = await (async()=>{const b=atob(document.getElementById('data').textContent.trim());const u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);const ds=new DecompressionStream('gzip');const w=ds.writable.getWriter();w.write(u);w.close();return JSON.parse(await new Response(ds.readable).text());})();
const AREAS = DATA.areas, DOCS = DATA.docs, UPDATED = DATA.updated;
const ORDER = Object.keys(AREAS); const NPM=DATA.npm, NGL=DATA.ngl; const T0=performance.now();""",
"""const DATA = await (await fetch('data/index.json?v='+encodeURIComponent(document.documentElement.dataset.v||''),{cache:'no-cache'})).json();
const AREAS = DATA.areas, DOCS = DATA.docs, UPDATED = DATA.updated, SHARDS = DATA.shards;
const ORDER = Object.keys(AREAS); const NPM=DOCS.filter(d=>d.kind!=='gl').length, NGL=DOCS.filter(d=>d.kind==='gl').length; const T0=performance.now();
const BYID = new Map(DOCS.map(d=>[d.id,d]));""")

# 2. incremental index
rep("""const chunks=[]; const df=new Map();
DOCS.forEach((d,di)=>{
  d.old = d.kind!=='gl' && (d.yr && +d.yr<2022 || /utgick|utgått/i.test(d.note||''));
  d.fresh = d.yr && +d.yr>=2025;
  d.chunks=[];
  d.c.forEach((c,ci)=>{
    const t=toks(c[1]); const tf=new Map();
    t.forEach(w=>tf.set(w,(tf.get(w)||0)+1));
    const ch={d:di,i:ci,pg:c[0],text:c[1],tf,len:t.length,toc:!!c[2]};
    chunks.push(ch); d.chunks.push(ch);
    tf.forEach((_,w)=>df.set(w,(df.get(w)||0)+1));
  });
  d.tt=new Set(toks(d.t));
});
console.log('index ms',Math.round(performance.now()-T0),'chunks',chunks.length,'terms',df.size);
const N=chunks.length, avg=chunks.reduce((a,c)=>a+c.len,0)/N;
const TERMS=[...df.keys()];
function idf(w){const n=df.get(w)||0;return Math.log(1+(N-n+.5)/(n+.5));}""",
"""const chunks=[]; const df=new Map(); let N=0, avg=1, TERMS=[], dirty=false;
DOCS.forEach((d,di)=>{
  d.di=di; d.old = d.kind!=='gl' && (d.yr && +d.yr<2022 || /utgick|utgått/i.test(d.note||''));
  d.fresh = d.yr && +d.yr>=2025; d.chunks=[]; d.loaded=false; d.tt=new Set(toks(d.t+' '+(d.soc||'')));
});
function addText(d,c){
  if(d.loaded) return; d.loaded=true;
  c.forEach((x,ci)=>{
    const t=toks(x[1]); const tf=new Map(); t.forEach(w=>tf.set(w,(tf.get(w)||0)+1));
    const ch={d:d.di,i:ci,pg:x[0],text:x[1],tf,len:t.length,toc:!!x[2]};
    chunks.push(ch); d.chunks.push(ch); tf.forEach((_,w)=>df.set(w,(df.get(w)||0)+1));
  });
  dirty=true;
}
function reindex(){ if(!dirty) return; N=chunks.length; avg=N?chunks.reduce((a,c)=>a+c.len,0)/N:1; TERMS=[...df.keys()]; dirty=false; }
// ---------- shards (one JSON per area, loaded on demand + prefetched in the background) ----------
const loadedAreas=new Set(), loading=new Map(); let prefetchDone=false;
function loadArea(a){
  if(!SHARDS[a]||loadedAreas.has(a)) return Promise.resolve();
  if(loading.has(a)) return loading.get(a);
  const p=fetch(SHARDS[a]+'?v='+encodeURIComponent(DATA.v)).then(r=>{if(!r.ok)throw new Error(r.status);return r.json();}).then(j=>{
    Object.entries(j.docs).forEach(([id,c])=>{const d=BYID.get(id);if(d)addText(d,c);});
    loadedAreas.add(a); loading.delete(a); setLoadStat();
  }).catch(e=>{loading.delete(a);console.warn('shard',a,e);});
  loading.set(a,p); return p;
}
function setLoadStat(){const el=$('ldst');if(!el)return;const n=loadedAreas.size,t=Object.keys(SHARDS).length;el.textContent=n<t?`Hämtar PM-text för sökning… ${n}/${t} områden`:'';el.hidden=n>=t;}
async function prefetchAll(){for(const a of ORDER){if(SHARDS[a]&&!loadedAreas.has(a)){await loadArea(a);if(state.q)update();}}prefetchDone=true;setLoadStat();if(!state.q&&!state.area&&$('reader').hidden)update();}
function idf(w){const n=df.get(w)||0;return Math.log(1+(N-n+.5)/(n+.5));}""")

# 3. search: reindex + title-only groups for docs without text
rep("""  const exp=terms.map(expand); const k1=1.4,b=.6; const res=[];""",
    """  reindex(); const exp=terms.map(expand); const k1=1.4,b=.6; const res=[];""")
rep("""  const groups=[];
  byDoc.forEach(g=>{""",
    """  const groups=[];
  // documents without loaded text (link-only riktlinjer, or shards not yet fetched): match on title + society
  DOCS.forEach(d=>{ if(byDoc.has(d.di)||d.chunks.length) return; let m=0; for(const w of terms){for(const t of d.tt){if(t===w||t.startsWith(w)||(w.length>=5&&t.includes(w))){m++;break;}}}
    if(terms.length&&m===terms.length) byDoc.set(d.di,{d,hits:[],score:0,titleOnly:true}); });
  byDoc.forEach(g=>{
    if(g.titleOnly){ g.score=8*terms.length*(g.d.kind==='gl'&&state.kind!=='gl'?0.85:1); groups.push(g); return; }""")

# 4. cards: "Läs här" only when text exists; link-only otherwise
rep("""el.innerHTML=`<div class="dh"><div class="t"><b>${esc(d.t)}</b><div class="meta">${tagsFor(d,withArea)}</div></div>${favBtn(d)}</div><div class="actions"><button data-act="open">Läs här</button>${srcLink(d)}${saveBtn(d)}</div>`;
  el.querySelector('.dh').onclick=()=>openReader(d,[],[]);
  el.querySelector('[data-act=open]').onclick=()=>openReader(d,[],[]);""",
"""el.innerHTML=`<div class="dh"><div class="t"><b>${esc(d.t)}</b><div class="meta">${tagsFor(d,withArea)}</div></div>${favBtn(d)}</div><div class="actions">${d.txt?'<button data-act="open">Läs här</button>':''}${srcLink(d)}${saveBtn(d)}</div>`;
  el.querySelector('.dh').onclick=()=>openReader(d,[],[]);
  const ob=el.querySelector('[data-act=open]'); if(ob)ob.onclick=()=>openReader(d,[],[]);""")
rep("""function srcLink(d){return d.kind==='gl'?`<a href="${d.url}" target="_blank" rel="noopener">Källa ↗</a>`:`<a href="${d.url}" target="_blank" rel="noopener">DocPlus ↗</a>`;}""",
    """function srcLink(d){return d.kind==='gl'?`<a href="${d.url}" target="_blank" rel="noopener">${d.txt?'Källa':'Öppna riktlinjen'} ↗</a>`:`<a href="${d.url}" target="_blank" rel="noopener">DocPlus ↗</a>`;}""")
# tag for link-only
rep("""<span class="tag soc">${esc(d.soc)}</span>""", """<span class="tag soc">${esc(d.soc)}</span>${d.txt?'':'<span class="tag lnk">länk</span>'}""")

# 5. search result card: title-only hits
rep("""    for(let i=0;i<lim;i++){const x=g.hits[i];hits+=`<div class="hit" data-i="${i}"><span class="pg">s. ${x.pg}</span>${fmt(x.text,r.terms,r.phrases,true)}</div>`;}""",
"""    for(let i=0;i<lim;i++){const x=g.hits[i];hits+=`<div class="hit" data-i="${i}"><span class="pg">s. ${x.pg}</span>${fmt(x.text,r.terms,r.phrases,true)}</div>`;}
    if(g.titleOnly) hits=`<div class="hit tonly">${d.txt?(loadedAreas.has(d.a)?'Träff i titeln':'Träff i titeln – texten hämtas…'):'Träff i titeln – öppna riktlinjen via länken'}</div>`;""")
rep("""<span class="score">${g.hits.length} träff${g.hits.length>1?'ar':''}</span>""",
    """<span class="score">${g.titleOnly?'titel':g.hits.length+' träff'+(g.hits.length>1?'ar':'')}</span>""")
rep("""<div class="actions"><button data-act="open">Öppna ${kindLabel(d)} med markeringar</button>${srcLink(d)}${saveBtn(d)}</div>`;
    el.querySelector('.dh').onclick=()=>openReader(d,r.terms,r.phrases);
    el.querySelector('[data-act=open]').onclick=()=>openReader(d,r.terms,r.phrases);""",
"""<div class="actions">${d.txt?`<button data-act="open">Öppna ${kindLabel(d)} med markeringar</button>`:''}${srcLink(d)}${saveBtn(d)}</div>`;
    el.querySelector('.dh').onclick=()=>openReader(d,r.terms,r.phrases);
    const ob=el.querySelector('[data-act=open]'); if(ob)ob.onclick=()=>openReader(d,r.terms,r.phrases);""")

# 6. area view: make sure the shard is loaded (for reader), render immediately anyway
rep("""function renderArea(main){
  const docs=DOCS.filter(docPass);""",
"""function renderArea(main){
  loadArea(state.area);
  const docs=DOCS.filter(docPass);""")

# 7. reader: load shard first; link-only docs open the source
rep("""function openReader(d,terms,phrases,page){
  recents=[d.id,...recents.filter(x=>x!==d.id)].slice(0,8); store.set('recent',recents);""",
"""function openReader(d,terms,phrases,page){
  if(!d.txt){ window.open(d.url,'_blank','noopener'); return; }
  if(!d.loaded){ setStat('Hämtar text…'); loadArea(d.a).then(()=>{ if(d.loaded) openReader(d,terms,phrases,page); else setStat('Kunde inte hämta texten – kontrollera uppkopplingen.'); }); return; }
  recents=[d.id,...recents.filter(x=>x!==d.id)].slice(0,8); store.set('recent',recents);""")

# 8. home: label + start prefetch; stat
rep("""<h3>Internationella riktlinjer</h3><span style="font-size:12px;color:var(--muted)">${gld.length} dokument · ERC, ESC, ESO, NICE, RCEM, ACEP, WSES m.fl.</span>""",
    """<h3>Internationella riktlinjer</h3><span style="font-size:12px;color:var(--muted)">${gld.length} länkar · ERC, ESC, ESO, NICE, RCEM, ACEP, WSES m.fl. – öppnas hos utgivaren</span>""")
rep("""const bt=$('boot');if(bt)bt.remove();
update();""",
"""const bt=$('boot');if(bt)bt.remove();
update(); setLoadStat();
(window.requestIdleCallback||(f=>setTimeout(f,300)))(()=>prefetchAll());""")
# search typed before prefetch complete: load everything now (prefetch already running; nothing extra)

# 9. footer + boot text + load status element
head = head.replace('<main class="main" id="main"><div id="boot">Laddar PM och riktlinjer…</div></main>',
                    '<main class="main" id="main"><div id="boot">Laddar…</div></main>')
head = head.replace('<span class="stat" id="stat"></span>', '<span class="stat" id="stat"></span><span class="stat" id="ldst" hidden></span>')
head = re.sub(r'<footer>.*?</footer>',
 '<footer>PM: texten är hämtad från de offentliga DocPlus-PDF:erna (Region Uppsala). Internationella riktlinjer visas som länkar till utgivaren (ingen text lagras här). Personligt urval av Kjell Stefansson, ST-läkare akutsjukvård – ersätter inte DocPlus. Sökningen sker helt lokalt i webbläsaren; inget skickas någonstans. ⚠ = PM ≥ 4 år gammalt eller med utgången giltighet.</footer>', head, flags=re.S)
head = head.replace('<html lang="sv">', f'<html lang="sv" data-v="{VERSION}">', 1)
# css for link tag / title-only hit
head = head.replace('</style>', '.tag.lnk{background:#eef1f5;color:#556}.hit.tonly{color:var(--muted);font-style:italic}</style>', 1)
assert 'data-v=' in head
js = js.replace("</script></script>", "</script>", 1)
open(f'{dist}/index.html', 'w', encoding='utf8').write(head + js)

# ---------- sw ----------
open(f'{dist}/sw.js', 'w').write(f"""// Akutkompassen service worker – app shell + data shards, works offline after first visit.
// Bump VERSION on every release (build.py does this).
const VERSION = '{VERSION}';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png', './data/index.json'];
self.addEventListener('install', e => {{
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
}});
self.addEventListener('activate', e => {{
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
}});
self.addEventListener('fetch', e => {{
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;                 // DocPlus, publishers, fonts → network
  if (url.pathname.includes('/data/') && !url.pathname.endsWith('index.json')) {{
    // shards are immutable per VERSION: cache first
    e.respondWith(caches.open(VERSION).then(c => c.match(e.request, {{ignoreSearch:true}}).then(r => r || fetch(e.request).then(n => {{ if (n.ok) c.put(e.request, n.clone()); return n; }}))));
    return;
  }}
  // shell + index: network first, cache fallback
  e.respondWith(fetch(e.request).then(r => {{ const copy = r.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)); return r; }})
    .catch(() => caches.open(VERSION).then(c => c.match(e.request, {{ignoreSearch:true}})).then(r => r || caches.match('./index.html'))));
}});
""")
for f in ('manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png', 'favicon.png'):
    shutil.copy(f'{S}/v9/{f}', dist)
open(f'{dist}/README.md', 'w', encoding='utf8').write(open(f'{S}/README_v10.md', encoding='utf8').read().replace('{VERSION}', VERSION))
sizes = {f: os.path.getsize(f'{dist}/{f}') for f in ['index.html', 'data/index.json']}
sh = sorted(((a, os.path.getsize(f'{dist}/data/{a}.json')) for a in shards), key=lambda x: -x[1])
print(sizes, 'shards', len(sh), 'total', sum(s for _, s in sh), sh[:5])
