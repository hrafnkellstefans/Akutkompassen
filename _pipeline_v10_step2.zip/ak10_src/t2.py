import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1200,'height':900})
        await pg.route('**/*',lambda r: r.abort() if 'localhost' not in r.request.url else r.continue_())
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_selector('.acard')
        for q in ['ERC advanced life support','NICE head injury','sepsis','trombolys kontraindikation']:
            await pg.fill('#q',q); await pg.wait_for_timeout(700)
            titles=await pg.locator('.doc .t b').all_inner_texts()
            print(q,'|',await pg.inner_text('#stat'),'| gl:',await pg.locator('.doc.gl').count(),'| top3:',titles[:3])
        await pg.screenshot(path='shot_search.png')
        await b.close()
asyncio.run(main())
